"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from movies.views import home_view
from movies.views import stats_view
from movies.views import search_movies
from movies.views import movie_detail
from movies.views import movie_list
from movies.views import movies_stats_view

urlpatterns = [
    path('', home_view, name='home'),
    path('admin/', admin.site.urls),
    path('stats/', stats_view, name='stats'),
    path('search/', search_movies, name='search'),
    path('movie/<str:movie_id>/', movie_detail, name='movie_detail'),
    path('movies/', movie_list, name='movie_list'),
    path('movies_stats/', movies_stats_view, name='movies_stats_view'),
]
